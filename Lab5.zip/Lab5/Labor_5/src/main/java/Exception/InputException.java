package Exception;

/**
 * the InputException is an exception class
 * the class is used when an invalid input was introduced
 *
 * @author DOMBOS DAVID
 * @version  21.12.2021
 * @since 1.0
 */
public class InputException extends Exception {
    public InputException(String s) {
        System.out.println(s);
    }
}
